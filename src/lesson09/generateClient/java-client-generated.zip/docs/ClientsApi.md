# ClientsApi

All URIs are relative to *http://localhost:8080/api/v1/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAllClients**](ClientsApi.md#getAllClients) | **GET** /clients | Метод получения списка клиентов

<a name="getAllClients"></a>
# **getAllClients**
> Clients getAllClients()

Метод получения списка клиентов

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ClientsApi;


ClientsApi apiInstance = new ClientsApi();
try {
    Clients result = apiInstance.getAllClients();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ClientsApi#getAllClients");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Clients**](Clients.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: adplication/json

