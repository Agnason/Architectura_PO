# Client

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**FIO** | **String** |  | 
**country** | **String** |  | 
**eMail** | **String** |  | 
